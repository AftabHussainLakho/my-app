import React from 'react'

export default function Shop() {
    return (
        <>
        <h1>Shooop page</h1>
        </>
    )
}
